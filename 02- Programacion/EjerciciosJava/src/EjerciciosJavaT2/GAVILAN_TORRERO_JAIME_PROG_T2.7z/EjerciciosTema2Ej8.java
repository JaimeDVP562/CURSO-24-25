public class EjerciciosTema2Ej8 {

    public static void main(String[] args) {
        char caracter1 = 's';
        char caracter2 = 'a';
        char caracter3 = 'l';
        char caracter4 = 'u';
        char caracter5 = 'd';

        System.out.println(("") + caracter1 + caracter2  + caracter3 + caracter4 + caracter5);
        System.out.printf("%c%c%c%c%c\n", caracter1, caracter2, caracter3, caracter4, caracter5);
    }

}

/*8. Escribe un programa que declare 5 variables de tipo char. A continuación, crea otra variable como cadena de caracteres y asígnale como valor la concatenación de las anteriores 5 variables. Por último, muestra la cadena de caracteres por pantalla
¿Qué problemas te encuentras? ¿cómo lo has solucionado?
Ejemplo:
Se crean 5 variables con los valores 's'. 'a'. '1'. 'u' y 'd' respectivamente y luego se concatenan.
salud */
